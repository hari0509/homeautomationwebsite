import cv2
import numpy as np
import serial
import os
import time
import sys
face_detect = cv2.CascadeClassifier(r"inc\haar.xml")
cap = cv2.VideoCapture(r"inc\videoplayback.mp4")

while (True):
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    face = face_detect.detectMultiScale(gray, 1.2, 2)
    for (x, y, w, h) in face:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        roi_color = frame[y:y + h, x:x + w]
        roi_gray = frame[y:y + h, x:x + w]
    cv2.imshow('frame', frame)

    k = cv2.waitKey(10) & 0xff
    if k == ord('q'):
        break

cap.release()
cv2.DestroyAllWindows()
#modified one